#########################################################################
# File Name: runRelease.sh
# Author: Yibo Lin
# mail: yibolin@utexas.edu
# Created Time: Thu 07 Jan 2016 09:30:27 PM CST
#########################################################################
#!/bin/bash

./TPLPlacerRelease -lef ./benchDPlace/sparc_15nm/NanGate_15nm_OCL.lef \
    -target_util .85 \
    -inlib ./benchDPlace/sparc_15nm/efc_85 \
    -cellPath ./benchCells/nangate_color_15nm \
    -maxDisp 5 \
    -out efc_85.out
